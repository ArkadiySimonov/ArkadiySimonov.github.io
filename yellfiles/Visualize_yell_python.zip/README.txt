The files in this folder show how to visualize the Yell output using standard python capabilities.

In order to run 'visualize_yell.py' the python 2 is required along with the libraries numpy, h5py and matplotlib.

The file 'Visualize Yell dataset.ipynb' should be run in the ipython notebook. It also requires the h5py library to be installed.