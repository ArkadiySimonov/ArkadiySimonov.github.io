# Authors: Arkadiy Simonov, Logvinovich Dmitry

# This is free and unencumbered software released into the public domain.

# Anyone is free to copy, modify, publish, use, compile, sell, or
# distribute this software, either in source code form or as a compiled
# binary, for any purpose, commercial or non-commercial, and by any
# means.

# In jurisdictions that recognize copyright laws, the author or authors
# of this software dedicate any and all copyright interest in the
# software to the public domain. We make this dedication for the benefit
# of the public at large and to the detriment of our heirs and
# successors. We intend this dedication to be an overt act of
# relinquishment in perpetuity of all present and future rights to this
# software under copyright law.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
# OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
# ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.

# For more information, please refer to <http://unlicense.org/>

import h5py
from numpy import reshape,max
from matplotlib import cm
from matplotlib.pyplot import show, subplots
import os

def read_from_yell(filename):
    """Loads dataset from Yell output files"""
    return h5py.File(filename,'r')['/data'][()]

#load PDF map
path='' #path to the folder with yell dataset. can be kept blank if the script is run from within that folder
dataset_name = 'delta-pdf.h5' #also applicable for exp-delta-pdf.h5 and delta-delta-pdf.h5
model_pdf=read_from_yell(os.path.join(path,dataset_name))
model_pdf=model_pdf/max(reshape(model_pdf,model_pdf.size))

#draw PDF map, the following two variables select crossection, and image saturation and should be controlled by user
z=101 #position of xyZ crossection, in pixels
c=0.005 #controls the color saturation
map_limits = [-5,5,-5,5] #the extent of calculated map. in current case it is 5 unit cells

fig,ax=subplots(figsize=(15,15))
cax=ax.imshow(model_pdf[:,:,z],interpolation='nearest',cmap=cm.Spectral_r,extent=map_limits) #plot PDF
cax.set_clim((-c,c))
cbar = fig.colorbar(cax) #setup colorbar
cbar.set_label('P/Pmax')
ax.set_title('Delta PDF') #add titles to axis
ax.set_xlabel('x')
ax.set_ylabel('y')
show()

#load diffuse scattering
intensity_dataset_name = 'model.h5'
model_diffuse_scattering=read_from_yell(os.path.join(path,intensity_dataset_name))

#draw diffuse scattering, the following variable controls the crossection of the diffuse scattering
l=101 #position of hkL crossection, in pixels
map_limits = [-10,10,-10,10] #the extent of calculated map. in current case it is 10 reciprocal unit cells

fig,ax=subplots(figsize=(15,15))
cax=ax.imshow(model_diffuse_scattering[:,:,l],interpolation='nearest',cmap=cm.gist_gray_r,extent=map_limits) #plot PDF
cax.set_clim((0,200))
cbar = fig.colorbar(cax) #setup colorbar
cbar.set_label('I, arbitrary units')
ax.set_title('I') #add titles to the image and axis
ax.set_xlabel('h')
ax.set_ylabel('k')
show()
